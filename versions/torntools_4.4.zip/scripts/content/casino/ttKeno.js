window.addEventListener('load', async (event) => {
    console.log("TT - Casino | Keno");

    if(await flying() || await abroad())
        return;

    local_storage.get(["settings", "keno"], function([settings, keno]){
        if(!settings.pages.casino.all || !settings.pages.casino.blackjack)
            return;

        casinoGameLoaded().then(function(loaded){
            if(!loaded)
                return;

            // doc.find(".startGame").addEventListener("click", function(){
            //     if(doc.find(".bet-confirm").style.display != "block"){
            //         setTimeout(Main, 3000);
            //     }
            // });

            // // bet confirm
            // doc.find(".bet-confirm .yes").addEventListener("click", function(){
            //     setTimeout(Main, 3000);
            // });

            // // remove action when chosen option
            // for(let li of doc.findAll(".d-buttons-wrap li")){
            //     li.addEventListener("click", function(){
            //         if(doc.find(".tt-blackjack-action"))
            //             doc.find(".tt-blackjack-action").remove();

            //     });
            // }
        });
    });
});

// let numbers = [];
// for(let element of document.querySelectorAll("#KENOBOARDID .ITEMCLASS")){
//     if(element.classList.contains(".SUCCESS") || element.classList.contains(".FAIL")){
//         numbers.push(element.innerText);
//     }
// }
// console.log("Numbers played this round:", numbers);