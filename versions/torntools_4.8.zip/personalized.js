export default {
    "master": "", //"2087524",
    "users": {
        "2125456": ["mass_messages"]
    }
}