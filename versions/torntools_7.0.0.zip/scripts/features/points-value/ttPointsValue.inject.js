initializeTooltip(".tt-points-value", "white-tooltip");
