window.onload = () => {
	console.log("EXTENSION", "missions")

	browser.storage.local.get(["completed", "userdata", "torndata", "tabs"], function(data){
		var ach = false;
		for(let tab of data["tabs"]){
			if(tab === "achievements"){
				ach = true;
			}
		}
		
		if(ach){
			const completed = data["completed"];
			const stats = data["userdata"];
			const honors = data["torndata"]["honors"];

			const ps = stats["personalstats"]
			const status = getStatus()
			
			// CREATE WINDOW
			window_ = createAwardsWindow();
			
			console.log('Stats retrieved', stats);
			console.log("Honors retrieved", honors);

			var items = {
				"Stalemates": {stats: ps["defendsstalemated"], ach: []},
				"Stealthed": {stats: ps["attacksstealthed"], ach: []},
				"Attacks won": {stats: ps["attackswon"], ach: [], incl: ["win"]},
				"Defends won": {stats: ps["defendswon"], ach: [], incl: ["win"]},
				"Assist": {stats: ps["attacksassisted"], ach: []},
				"Critical hits": {stats: ps["attackcriticalhits"], ach: []},
				"Current streak": {stats: ps["killstreak"], ach: [], alt: ["###"]},
				"Best streak": {stats: ps["bestkillstreak"], ach: [], alt: ["Killstreak"]},
				"Rounds fired": {stats: ps["roundsfired"], ach: []},
				"Axe hits": {stats: ps["axehits"], ach: []},
				"Pistol hits": {stats: ps["pishits"], ach: []},
				"Rifle hits": {stats: ps["rifhits"], ach: []},
				"Shotgun hits": {stats: ps["shohits"], ach: []},
				"Piercing hits": {stats: ps["piehits"], ach: []},
				"Heavy hits": {stats: ps["heahits"], ach: []},
				"SMG hits": {stats: ps["smghits"], ach: []},
				"Machine gun hits": {stats: ps["machits"], ach: [], incl: ["guns"]},
				"Fists or kick hits": {stats: ps["h2hhits"], ach: []},
				"Mechanical hits": {stats: ps["chahits"], ach: []},
				"Temporary hits": {stats: ps["grehits"], ach: []}
			}

			items = setItemHonors(items, honors);

			console.log("ITEMS", items)

			appendItems(items, window_.inner_content, completed);
			setAwardsWindow(window_, status);
		} else {
			console.log("ACHIEVEMENTS TURNED OFF")
		}
	})

}

String.prototype.capitalize = function () {
  return this.replace(/^./, function (match) {
    return match.toUpperCase();
  });
};

function createAwardsWindow(){
	// Create window
	var containers = document.getElementsByClassName("sidebar-block___1Cqc2");
	var last_block = containers[containers.length-1]

	var content = document.createElement("div");
	var block = document.createElement("div");
	var header = document.createElement("h2");
	var inner_content = document.createElement("div");

	return {last_block: last_block, content: content, block: block, header: header, inner_content: inner_content}
}

function setAwardsWindow(window_, status){
	window_.header.innerText = "Awards";
	window_.content.classList.add("content___kMC8x");
	window_.block.classList.add("toggle-block___13zU2");
	window_.header.classList.add("header___30pTh");
	window_.header.classList.add("desktop___vemcY")
	if(status == "hospital"){window_.header.classList.add("in-hospital___3XdP8")}
	else if(status == "jail"){window_.header.classList.add("in-jail___nwOPJ")}
	window_.inner_content.classList.add("toggle-content___3XKOC");

	window_.block.appendChild(window_.header)
	window_.block.appendChild(window_.inner_content)
	window_.content.appendChild(window_.block)
	window_.last_block.insertBefore(window_.content, window_.last_block.firstChild)
}

function getStatus(){
	let nav = document.querySelector("#sidebarroot");
	
	if(!nav){
		return "flying";
	}
	
	let hdr = nav.firstElementChild.firstElementChild
				.firstElementChild.firstElementChild
				.firstElementChild.firstElementChild
				.firstElementChild;

	for(let class_ of hdr.classList){
		if(class_.indexOf("hospital") !== -1){
			return "hospital";
		} else if (class_.indexOf("in-jail") !== -1){
			return "jail";
		}
	}
	return "okay";
}

function addRow(html, inner_content){
	let row = document.createElement("div");
	let row_inner = document.createElement("div");
	row.classList.add("area-desktop___29MUo");
	if(status == "hospital"){row.classList.add("in-hospital___2RRIG")}
	else if(status == "jail"){row.classList.add("in-jail___3XdP8")}
	row_inner.innerText = numberWithCommas(html);
	row_inner.classList.add("area-row___51NLj")
	row_inner.style.height = "23px"
	row_inner.style.lineHeight = "23px"
	row_inner.style.paddingLeft = "5px"

	if(html.slice(-10) === "Completed!"){
		row_inner.style.color = "#11c511"
	}

	row.appendChild(row_inner)
	inner_content.appendChild(row)
}

function setItemHonors(items, honors){
	for(let item in items){
		let term;
		if(items[item]["alt"]){
			term = items[item]["alt"][0]
			if(term === "###"){
				continue;
			}
		} else {
			term = item.split(" ")[0]
		}

		for(let honor in honors) {
			let desc = honors[honor].description;

			if(desc.indexOf(term) !== -1 || desc.indexOf(term.toLowerCase()) !== -1){
				if(items[item]["excl"]){
					let unique = true;
					for(let word of items[item]["excl"]){
						if(desc.indexOf(word) !== -1 || desc.indexOf(word.capitalize()) !== -1){
							unique = false
						}
					}
					if(unique){
						let nr = parseInt(desc.replace(/\D/g,''));
						if(!isNaN(nr)){
							items[item]["ach"].push(nr)
						}
					}
				} else if(items[item]["incl"]){
					let correct = true;
					for(let word of items[item]["incl"]){
						if(desc.indexOf(word) === -1 && desc.indexOf(word.capitalize()) === -1){
							correct = false;
						}
					}
					if(correct) {
						let nr = parseInt(desc.replace(/\D/g,''));
						if(!isNaN(nr)){
							items[item]["ach"].push(nr)
						}
					}
				} else {
					let nr = parseInt(desc.replace(/\D/g,''));
					if(!isNaN(nr)){
						items[item]["ach"].push(nr)
					}
				}
			}
		}
		items[item]["ach"].sort(function(a,b){return a-b})
	}

	return items
}

function appendItems(items, inner_content, completed){
	for(let item in items){
		let ach = items[item]["ach"]
		let stats = items[item]["stats"]
		let alt = items[item]["alt"]

		if(alt && alt[0] === "###"){
			addRow(`${item}: ${stats}`, inner_content);
			continue;
		}

		if(!stats){
			addRow(`${item}: 0/${ach[0]}`, inner_content)
		} else if (stats >= ach[ach.length-1] && completed === "show") {
			addRow(`${item}: Completed!`, inner_content)
		} else {
			for(let milestone of ach){
				if(stats < milestone){
					addRow(`${item}: ${stats}/${milestone}`, inner_content)
					break;
				}
			}
		}
	}
}

const numberWithCommas = (x) => {
	return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}