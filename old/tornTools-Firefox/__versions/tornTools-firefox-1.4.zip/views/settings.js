const changeLog = {
	"v1.4": [
		"Fixed bug where trade values where not displayed in case of 0 items",
		"Added changelog",
		"Removed help section from settings",
		"Reduced api request amount in trade view. Set api limit to 60 requests on trade view."
	]
}

window.onload = () => {
	setUpWindow();
}

function setUpWindow(){
	browser.storage.local.get(["default_window", "tabs", "completed", "tradecalc", "networth"], function(data){
		const settings = {
			def_win: data["default_window"],
			tabs: data["tabs"],
			completed: data["completed"],
			tradecalc: data["tradecalc"],
			networth: data["networth"]
		}

		setSettings(settings);

		const api_field = document.querySelector("#api-input");
		const api_button = document.querySelector("#change-api");
		const checks = document.querySelectorAll("#checks input");
		const radios = document.querySelectorAll("#def_windows input");
		const ach_compl = document.querySelector("#achievements-completed");
		const changelog_ul = document.querySelector("#changelog");
		const currentVersion = document.querySelector("#current-version");
		//const networth_refresh = document.querySelector("#networth-refresh");

		// EVENT LISTENERS
		for(let check of checks){
			check.addEventListener("click", function(){
				applySettings();
			});
		}
		for(let radio of radios){
			radio.addEventListener("click", function(){
				applySettings();
			});
		}

		ach_compl.addEventListener("click", function(){
			applySettings();
		})

		api_button.addEventListener("click", function(){
			let api_key = api_field.value;

			browser.storage.local.set({"api_key": api_key}, function(){
				console.log("API KEY SET");
				getTornItemList(api_key);
			});
		});

		// networth_refresh.addEventListener("click", function(){
		// 	brwoser.storage.local.get(["api_key"], function(data){
		// 		const api_key = data["api_key"];
		// 		setNetworth(api_key);
		// 	});
		// });

		let ver = browser.runtime.getManifest().version
		currentVersion.innerText = "Current version: " + ver;

		// ADD CHANGELOG
		for(let v in changeLog){
			let mainSection = document.createElement("li");
			let lowerSection = document.createElement("ul");
			mainSection.innerText = v;
			if(v.indexOf(ver) != -1){
				mainSection.style.backgroundColor = "#ffff0240";
			}

			for(let bug of changeLog[v]){
				let li = document.createElement("li");
				li.innerText = bug;
				lowerSection.appendChild(li);	
			}

			mainSection.appendChild(lowerSection);
			changelog_ul.appendChild(mainSection);
		}
	});
}

function setSettings(s){
	var checks = document.querySelectorAll("#checks input:not(.secondary)");
	for(let check of checks){
		for(let tab of s["tabs"]){
			if(check.nextElementSibling.innerText.indexOf(tab) > -1){
				check.checked = true;
			}
		}
	}

	var ach_compl = document.querySelector("#achievements-completed");
	if(s["completed"] === "show"){
		ach_compl.checked = true;
	}

	var radios = document.querySelectorAll("#def_windows input");
	for(let radio of radios){
		if(radio.nextElementSibling.innerText.toLowerCase() === s["def_win"]){
			radio.checked = true;
		}
	}

	var trade_calculator = document.querySelector("#calculator-trade");
	if(s["tradecalc"] === "show"){
		trade_calculator.checked = true;
	}

	// var networth_check = document.querySelector("#otherchecks #networth-check");
	// if(s["networth"] === "show"){
	// 	networth_check.checked = true;
	// }
}

function applySettings(){
	var tabs = [];
	var def_window;
	var completed;
	var tradecalc;
	// var networth;

	var checks = document.querySelectorAll("#checks input:not(.secondary)");
	for(let check of checks){
		if(check.checked){
			tabs.push(check.value);
		}
	}

	var radios = document.querySelectorAll("#def_windows input");
	for(let radio of radios){
		if(radio.checked){
			def_window = radio.nextElementSibling.innerText.toLowerCase();
		}
	}

	var ach_compl = document.querySelector("#achievements-completed");
	if(ach_compl.checked){
		completed = "show";
	} else {
		completed = "hide";
	}

	var trade_calculator = document.querySelector("#calculator-trade");
	if(trade_calculator.checked){
		tradecalc = "show";
	} else {
		tradecalc = "hide";
	}

	// var networth_check = document.querySelector("#otherchecks #networth-check");
	// if(networth_check.checked){
	// 	networth = "show";
	// } else {
	// 	networth = "hide";
	// }

	console.log(tabs)

	browser.storage.local.set({
		"default_window": def_window,
		"tabs": tabs,
		"completed": completed,
		"tradecalc": tradecalc//,
		// "networth": networth
	}, function(){
		console.log("SETTINGS SET")
	})
}

function getTornItemList(api_key){
	get_api("https://api.torn.com/torn/?selections=items", api_key).then((data) => {
		browser.storage.local.set({"itemlist": data}, function(){
			console.log("Itemlist set.");
			$("#message").text("Api key changed.");
			$("#message").slideDown("slow", function(){});
			setTimeout(function(){
				$("#message").slideUp("slow", function(){});
			}, 1500);
		});
	})
}

async function setNetworth(api_key){
	const inventory = await get_api(links.inventory, api_key).then(data => {
		return data["inventory"];
	});

	var totalValue = 0;
	var items = {};
	var itemString = "";

	for(let item of inventory){
		items[item["ID"]] = item["quantity"];
		itemString += String(item["ID"]) + ",";
	}

	itemString = itemString.slice(0, itemString.length-1);

	const prices = await get_api(`https://api.torn.com/market/${itemString}?selections=bazaar,itemmarket`, api_key);

	for(let item in prices){
		let lowest = getLowest([item["bazaar"], item["itemmarket"]]);
		totalValue += lowest * parseInt(items[item]);
	}

	chrome.storage.local.set({"networthValue": totalValue}, function(){
		console.log("Networth set.")
	});
}

function getLowest(lists){
	var lowest;

	for(let list of lists){
		for(let id in list){
			let price = parseInt(data[list][id]["cost"]);

			if(!lowest){
				lowest = price;
			} else if(price < lowest){
				lowest = price
			}
		}
	}
	return lowest;
}

async function get_api(http, api_key) {
  	const response = await fetch(http + "&key=" + api_key)
  	return await response.json()
}