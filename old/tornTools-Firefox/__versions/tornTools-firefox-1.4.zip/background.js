console.log("START");

const links = {
	itemlist: "https://api.torn.com/torn/?selections=items",
	userdata: "https://api.torn.com/user/?selections=personalstats,crimes,battlestats,perks,profile,workstats,stocks",
	torndata: "https://api.torn.com/torn/?selections=honors,stocks",
	inventory: "https://api.torn.com/user/?selections=inventory"
}

browser.runtime.onConnect.addListener(function(port) {
    port.onMessage.addListener(function(msg) {
        if(msg === "START"){
        	console.log("STARTING PROGRAM");
        	Main();
        } else {
        	console.log("FAILED");
        	console.log("MESSAGE - ", msg)
        }
    });
})

browser.alarms.onAlarm.addListener(function(alarm) {
    if (alarm.name == 'getMainData') {
    	browser.storage.local.get(["api_key"], function(data){
    		const api_key = data["api_key"];
        	getData(api_key);
    	});
    } else if(alarm.name === "networth"){
    	browser.storage.local.get(["api_key", "networth"], function(data){
    		const api_key = data["api_key"];
    		const networth = data["networth"];
    		if(networth === "show"){
        		setNetworth(api_key);
    		}
    	});
    }
});


function Main(){
	// MAIN DATA LOOP
	browser.alarms.create('getMainData', {
		periodInMinutes: 1
	});

	// NETWORHT LOOP
	browser.alarms.create('networth', {
		periodInMinutes: 60
	});

	// SET DEFAULT WINDOW
	browser.storage.local.set({"default_window": "market"}, function(){
		console.log("Defualt window set.");
	});

	// SET TABS
	browser.storage.local.set({"tabs": ["market", "stocks", "achievements", "calculator"]}, function(){
		console.log("Tabs set.");
	});

	// SET ACHIEVEMENT PREFERENCE
	browser.storage.local.set({"completed": "show"}, function(){
		console.log("Completed set.")
	});

	// SET TRADE CALCULATOR PREFERENCE
	browser.storage.local.set({"tradecalc": "show"}, function(){
		console.log("Trade calculator set.")
	});
	// SET NETWORTH DISPLAY PREFERENCE
	browser.storage.local.set({"networth": "show"}, function(){
		console.log("Trade calculator set.")
	});

	// GET DATA FIRST TIME
	browser.storage.local.get(["api_key"], function(data){
		const api_key = data["api_key"];

		getTornItemList(api_key);
		getData(api_key);
	});
}

function getData(api_key){
	get_api(links.userdata, api_key).then((data) => {
		browser.storage.local.set({"userdata": data}, function(){
			console.log("Userdata set.")
		});
	})

	get_api(links.torndata, api_key).then((data) => {
		browser.storage.local.set({"torndata": data}, function(){
			console.log("Torndata set.")
		});
	})
}

function getTornItemList(api_key){
	get_api(links.itemlist, api_key).then((data) => {
		browser.storage.local.set({"itemlist": data}, function(){
			console.log("Itemlist set.")
		});
	})
}

async function setNetworth(api_key){
	const inventory = await get_api(links.inventory, api_key).then(data => {
		return data["inventory"];
	});

	var totalValue = 0;
	var items = {};
	var itemString = "";

	for(let item of inventory){
		items[item["ID"]] = item["quantity"];
		itemString += String(item["ID"]) + ",";
	}

	itemString = itemString.slice(0, itemString.length-1);

	const prices = await get_api(`https://api.torn.com/market/${itemString}?selections=bazaar,itemmarket`, api_key);

	for(let item in prices){
		let lowest = getLowest([item["bazaar"], item["itemmarket"]]);
		totalValue += lowest * parseInt(items[item]);
	}

	brwoser.storage.local.set({"networthValue": totalValue}, function(){
		console.log("Networth value set.")
	});
}

function getLowest(lists){
	var lowest;

	for(let list of lists){
		for(let id in list){
			let price = parseInt(data[list][id]["cost"]);

			if(!lowest){
				lowest = price;
			} else if(price < lowest){
				lowest = price
			}
		}
	}
	return lowest;
}

async function get_api(http, api_key) {
  	const response = await fetch(http + "&key=" + api_key)
  	return await response.json()
}