const chrome = browser;
window.onload = () => {
	console.log("EXTENSION", "missions");
	(async () => {
		var tools = {};

		const mainModel = {
			initialize: function(){
				chrome.storage.local.get(["update"], function(data){
					const update = data["update"];
				
					const headers = document.querySelectorAll(".header___30pTh.desktop___vemcY");
					const version = chrome.runtime.getManifest().version;
					
					var container;
					for(let header of headers){
						if(header.innerText === "Areas"){
							container = header.parentElement.children[1];
						}
					}
					const nextElement = document.querySelector("#nav-home");

					let div = document.createElement("div");
					let innerDiv = document.createElement("div");
					let link = document.createElement("a");
					let span = document.createElement("span");
					let icon = document.createElement("div");

					div.classList.add("area-desktop___29MUo");
					innerDiv.classList.add("area-row___51NLj");
					if(update){
						innerDiv.style.backgroundColor = "#8eda53b0";
					}

					link.addEventListener("click", function(){
						chrome.runtime.sendMessage({"action": "openOptionsPage"});
					});

					span.innerHTML = `Torn<span style="font-weight:600;margin:0;line-height:7px;">Tools</span>  v${version}`;
					span.setAttribute("style", `
						height: 20px;
						line-height: 20px;
					`);

					const src = chrome.extension.getURL("images/icon50.png");
					icon.setAttribute("style", `
						width: 15px;
						height: 15px;
						background-size: cover;
						background-image: url(${src});
						margin-top: 2px;
						margin-left: 10px;
						margin-right: 6px;
						float: left;
					`)

					link.appendChild(icon)
					link.appendChild(span);
					innerDiv.appendChild(link);
					div.appendChild(innerDiv);
					container.insertBefore(div, nextElement);

					// functions
					tools.capitalize();
				});
			},
			get_api: async function(http, api_key){
				const response = await fetch(http + "&key=" + api_key)
				const result = await response.json()
				return result;
			},
			compare: function(a,b){
				if (a.cost < b.cost)
				  return -1;
				if (a.cost > b.cost)
				  return 1;
				return 0;
			},
			getLowest: function(lists){
				var lowest;

				for(let list in lists){
					for(let id in lists[list]){
						let price = parseInt(lists[list][id]["cost"]);

						if(!lowest){
							lowest = price;
						} else if(price < lowest){
							lowest = price
						}
					}
				}
				return lowest;
			},
			countPerks: function(perks){
				let total = 0;

				for(let perklist of perks){
					for(let perk of perklist){
						total++;
					}
				}

				return total
			},
			displayNetworth: function(x){
				const container = document.querySelector("#item4741013");
				const innerBox = container.children[1].children[0].children[0];
				const last = innerBox.children[innerBox.children.length-1];

				last.removeAttribute("class");

				let li = document.createElement("li");
				let spanL = document.createElement("span");
				let spanName = document.createElement("span");
				let spanR = document.createElement("span");
				let i = document.createElement("i");

				li.classList.add("last");
				li.style.backgroundColor = "#65c90069";
				spanL.classList.add("divider");
				spanR.classList.add("desc");
				i.classList.add("networth-info-icon");
				i.setAttribute("title", "Torn Tools: Your networth is fetched from Torn's API which may have a small delay. It is fetched every time your reload this page.");
				spanName.style.backgroundColor = "rgba(0,0,0,0)";

				spanName.innerText = "Networth"
				spanR.innerText = "$" + String(numberWithCommas(x));
				spanR.style.paddingLeft = "12px";
				
				spanL.appendChild(spanName);
				spanR.appendChild(i);
				li.appendChild(spanL);
				li.appendChild(spanR);
				innerBox.appendChild(li);
			},
			capitalize: function(){
				String.prototype.capitalize = function () {
				  	return this.replace(/^./, function (match) {
				    	return match.toUpperCase();
				  	});
				};
			},
			days: function(x){
				return Math.floor(x/60/60/24); // seconds, minutes, hours
			},
			hours: function(x){
				return Math.floor(x/60/60); // seconds, minutes
			},
			cleanNr: function(x){
				return String(parseInt(x).toFixed())
			},
			numberWithCommas: function(x){
				return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
			}
		}

		const achModel = {
			appendItems: function(items, inner_content, completed){
				for(let item in items){
					let ach = items[item]["ach"]
					let stats = items[item]["stats"]

					if(!stats){
						this.addRow(`${item}: 0/${ach[0]}`, inner_content)
					} else if (stats >= ach[ach.length-1] && completed) {
						this.addRow(`${item}: Completed!`, inner_content)
					} else {
						for(let milestone of ach){
							if(stats < milestone){
								this.addRow(`${item}: ${stats}/${milestone}`, inner_content)
								break;
							}
						}
					}
				}
			},
			setItemHonors: function(items, honors){
				for(let item in items){
					let term;
					if(items[item]["alt"]){
						term = items[item]["alt"][0]
					} else {
						term = item.split(" ")[0]
					}

					for(let honor in honors) {
						let desc = honors[honor].description;

						if(desc.indexOf(term) !== -1 || desc.indexOf(term.toLowerCase()) !== -1){
							if(items[item]["excl"]){
								let unique = true;
								for(let word of items[item]["excl"]){
									if(desc.indexOf(word) !== -1 || desc.indexOf(word.capitalize()) !== -1){
										unique = false
									}
								}
								if(unique){
									let nr = parseInt(desc.replace(/\D/g,''));
									if(!isNaN(nr)){
										items[item]["ach"].push(nr)
									}
								}
							} else if(items[item]["incl"]){
								let correct = true;
								for(let word of items[item]["incl"]){
									if(desc.indexOf(word) === -1 && desc.indexOf(word.capitalize()) === -1){
										correct = false;
									}
								}
								if(correct) {
									let nr = parseInt(desc.replace(/\D/g,''));
									if(!isNaN(nr)){
										items[item]["ach"].push(nr)
									}
								}
							} else {
								let nr = parseInt(desc.replace(/\D/g,''));
								if(!isNaN(nr)){
									items[item]["ach"].push(nr)
								}
							}
						}
					}
					items[item]["ach"].sort(function(a,b){return a-b})
				}

				return items
			},
			addRow: function(html, inner_content){
				let row = document.createElement("div");
				let row_inner = document.createElement("div");
				row.classList.add("area-desktop___29MUo");
				if(status == "hospital"){row.classList.add("in-hospital___2RRIG")}
				else if(status == "jail"){row.classList.add("in-jail___3XdP8")}
				row_inner.innerHTML = this.numberWithCommas(html);
				row_inner.classList.add("area-row___51NLj")
				row_inner.style.height = "23px"
				row_inner.style.lineHeight = "23px"
				row_inner.style.paddingLeft = "5px"

				if(html.slice(-10) === "Completed!"){
					row_inner.style.color = "#11c511"
				}

				row.appendChild(row_inner)
				inner_content.appendChild(row)
			},
			getStatus: function(){
				let nav = document.querySelector("#sidebarroot");
				
				if(!nav){
					return "flying";
				}
				
				let hdr = nav.firstElementChild.firstElementChild
							.firstElementChild.firstElementChild
							.firstElementChild.firstElementChild
							.firstElementChild;

				for(let class_ of hdr.classList){
					if(class_.indexOf("hospital") !== -1){
						return "hospital";
					} else if (class_.indexOf("in-jail") !== -1){
						return "jail";
					}
				}
				return "okay";
			},
			createAwardsWindow: function(){
				// Create window
				var containers = document.getElementsByClassName("sidebar-block___1Cqc2");
				var last_block = containers[containers.length-1]

				var content = document.createElement("div");
				var block = document.createElement("div");
				var header = document.createElement("h2");
				var inner_content = document.createElement("div");

				return {last_block: last_block, content: content, block: block, header: header, inner_content: inner_content}
			},
			setAwardsWindow: function(window_, status){
				window_.header.innerText = "Awards";
				window_.content.classList.add("content___kMC8x");
				window_.block.classList.add("toggle-block___13zU2");
				window_.header.classList.add("header___30pTh");
				window_.header.classList.add("desktop___vemcY")
				if(status == "hospital"){window_.header.classList.add("in-hospital___3XdP8")}
				else if(status == "jail"){window_.header.classList.add("in-jail___nwOPJ")}
				window_.inner_content.classList.add("toggle-content___3XKOC");

				window_.block.appendChild(window_.header)
				window_.block.appendChild(window_.inner_content)
				window_.content.appendChild(window_.block)
				window_.last_block.insertBefore(window_.content, window_.last_block.firstChild)
			}
		}

		const missionsModel = {
			displayMissionPrice: async function(reward, id, quantity, points, api_key, userPoints){
				let itemValue = await this.get_api(`https://api.torn.com/market/${id}?selections=bazaar,itemmarket`, api_key)
					.then(data => {
						var lowest = this.getLowest([data["bazaar"], data["itemmarket"]]);
						return lowest;
					})

				const container = document.querySelector(`li[data-ammo-info='${reward.getAttribute("data-ammo-info")}'] .act-wrap`);
				const lastElement = document.querySelector(`li[data-ammo-info='${reward.getAttribute("data-ammo-info")}'] .act-wrap .actions`)
				const image = document.querySelector(`li[data-ammo-info='${reward.getAttribute("data-ammo-info")}'] .img-wrap`);

				// MAKE CONTAINERS BIGGER
				reward.style.height = "160px";

				let div = document.createElement("div");
				let oneItem = document.createElement("div");
				let pointValue = document.createElement("div");
				let totalValue = itemValue*quantity;

				// ONE ITEM PRICE ON IMAGE
				oneItem.innerText = "$" + String(this.numberWithCommas(itemValue));
				oneItem.style.color = "#35f4be";
				oneItem.style.position = "absolute";
				oneItem.style.left = "20px";
				oneItem.style.bottom = "5px";
				oneItem.style.fontsize = "10px";

				image.appendChild(oneItem);

				// LOWER CONTAINER
				let allItems = document.createElement("div");
				allItems.innerHTML = `Total value: <span style="color: #678c00">$${String(this.numberWithCommas(totalValue))}</span>`;
				// allItems.style.color = "#678c00";
				allItems.style.textAlign = "left";
				allItems.style.paddingLeft = "5px";
				allItems.style.paddingTop = "50px";

				pointValue.innerHTML = `Point value: <span style="color: #678c00">$${this.numberWithCommas((totalValue/points).toFixed(0))}</span>`;
				// pointValue.style.color = "#678c00";
				pointValue.style.textAlign = "left";
				pointValue.style.paddingLeft = "5px";


				div.appendChild(allItems)
				div.appendChild(pointValue)
				container.insertBefore(div, lastElement);
			}
		}

		tools = {...tools, ...mainModel, ...achModel, ...missionsModel}

		// const sources = {
		// 	mainModel: 'scripts/models/mainModel.js',
		// 	achievementsModel: 'scripts/models/achievementsModel.js',
		// 	missionsModel: 'scripts/models/missionsModel.js'
		// }

		// for(let src in sources){
		// 	let funcs = await import(chrome.extension.getURL(sources[src]));
		// 	tools = {...tools, ...funcs}
		// }
		tools.initialize();
		Main(tools);
	})();
}

function Main(tools){
	chrome.storage.local.get(["settings", "userdata", "torndata", "api_key"], function(data){
		const settings = data["settings"];
		const ach = settings["other"]["achievements"];
		const missionValues = settings["other"]["missionValues"];
		const api_key = data["api_key"];
		
		if(ach){
			console.log("ACHIEVEMENTS");
			const completed = settings["other"]["completed"];
			const stats = data["userdata"];
			const honors = data["torndata"]["honors"];

			const ps = stats["personalstats"]
			const status = tools.getStatus()
			
			// CREATE WINDOW
			window_ = tools.createAwardsWindow();

			var items = {
				"Stalemates": {stats: ps["defendsstalemated"], ach: []},
				"Stealthed": {stats: ps["attacksstealthed"], ach: []},
				"Attacks won": {stats: ps["attackswon"], ach: [], incl: ["win"]},
				"Defends won": {stats: ps["defendswon"], ach: [], incl: ["win"]},
				"Assist": {stats: ps["attacksassisted"], ach: []},
				"Critical hits": {stats: ps["attackcriticalhits"], ach: []},
				"Current streak": {stats: ps["killstreak"], ach: [], alt: ["###"]},
				"Best streak": {stats: ps["bestkillstreak"], ach: [], alt: ["Killstreak"]},
				"Rounds fired": {stats: ps["roundsfired"], ach: []},
				"Axe hits": {stats: ps["axehits"], ach: []},
				"Pistol hits": {stats: ps["pishits"], ach: []},
				"Rifle hits": {stats: ps["rifhits"], ach: []},
				"Shotgun hits": {stats: ps["shohits"], ach: []},
				"Piercing hits": {stats: ps["piehits"], ach: []},
				"Heavy hits": {stats: ps["heahits"], ach: []},
				"SMG hits": {stats: ps["smghits"], ach: []},
				"Machine gun hits": {stats: ps["machits"], ach: [], incl: ["guns"]},
				"Fists or kick hits": {stats: ps["h2hhits"], ach: []},
				"Mechanical hits": {stats: ps["chahits"], ach: []},
				"Temporary hits": {stats: ps["grehits"], ach: []}
			}

			items = tools.setItemHonors(items, honors);
			tools.appendItems(items, window_.inner_content, completed);
			tools.setAwardsWindow(window_, status);
		} else {
			console.log("ACHIEVEMENTS TURNED OFF")
		}

		if(missionValues){
			console.log("MISSION REWARD VALUES")
			const rewards = document.querySelectorAll(".rewards-list li");
			const userPoints = parseInt(document.querySelector(".total-mission-points").innerText);

			for(let reward of rewards){
				// console.log("REWARD", reward)
				let data = JSON.parse(reward.getAttribute("data-ammo-info"))
				let name = data["name"];
				let quantity = parseInt(data["amount"]);
				let points = parseInt(data["points"]);
				let id = parseInt(data["image"]);
				let counter = parseInt(data["id"]);

				let act_wrap = document.querySelector(`ul.rewards-list li:nth-child(${counter+1}) .act-wrap`)
				act_wrap.style.boxSizing = "border-box";
				act_wrap.style.borderColor = "black";
				act_wrap.style.borderImage = "none";

				// MAKE THE PRICE RED IF NOT ENOUGH POINTS
				if(userPoints < points){
					act_wrap.style.borderTop = "1px solid red";
				} else {
					act_wrap.style.borderTop = "1px solid #2ef42e";
				}

				if(!id){continue}

				tools.displayMissionPrice(reward, id, quantity, points, api_key, userPoints);
			}
		} else {
			console.log("MISSION REWARD VALUES TURNED OFF")
		}
	})
}