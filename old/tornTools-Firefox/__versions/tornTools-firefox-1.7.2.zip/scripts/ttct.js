const chrome = browser;
window.onload = () => {
	console.log("EXTENSION christmas town");
	(async () => {
		// const src = chrome.extension.getURL('scripts/module.js');
		// const tools = await import(src);

		const tools = {
			initialize: function(){
				chrome.storage.local.get(["update"], function(data){
					const update = data["update"];
				
					const headers = document.querySelectorAll(".header___30pTh.desktop___vemcY");
					const version = chrome.runtime.getManifest().version;
					
					var container;
					for(let header of headers){
						if(header.innerText === "Areas"){
							container = header.parentElement.children[1];
						}
					}
					const nextElement = document.querySelector("#nav-home");

					let div = document.createElement("div");
					let innerDiv = document.createElement("div");
					let link = document.createElement("a");
					let span = document.createElement("span");
					let icon = document.createElement("div");

					div.classList.add("area-desktop___29MUo");
					innerDiv.classList.add("area-row___51NLj");
					if(update){
						innerDiv.style.backgroundColor = "#8eda53b0";
					}

					link.addEventListener("click", function(){
						chrome.runtime.sendMessage({"action": "openOptionsPage"});
					});

					span.innerHTML = `Torn<span style="font-weight:600;margin:0;line-height:7px;">Tools</span>  v${version}`;
					span.setAttribute("style", `
						height: 20px;
						line-height: 20px;
					`);

					const src = chrome.extension.getURL("images/icon50.png");
					icon.setAttribute("style", `
						width: 15px;
						height: 15px;
						background-size: cover;
						background-image: url(${src});
						margin-top: 2px;
						margin-left: 10px;
						margin-right: 6px;
						float: left;
					`)

					link.appendChild(icon)
					link.appendChild(span);
					innerDiv.appendChild(link);
					div.appendChild(innerDiv);
					container.insertBefore(div, nextElement);

					// functions
					tools.capitalize();
				});
			},
			get_api: async function(http, api_key){
				const response = await fetch(http + "&key=" + api_key)
				const result = await response.json()
				return result;
			},
			compare: function(a,b){
				if (a.cost < b.cost)
				  return -1;
				if (a.cost > b.cost)
				  return 1;
				return 0;
			},
			getLowest: function(lists){
				var lowest;

				for(let list in lists){
					for(let id in lists[list]){
						let price = parseInt(lists[list][id]["cost"]);

						if(!lowest){
							lowest = price;
						} else if(price < lowest){
							lowest = price
						}
					}
				}
				return lowest;
			},
			countPerks: function(perks){
				let total = 0;

				for(let perklist of perks){
					for(let perk of perklist){
						total++;
					}
				}

				return total
			},
			displayNetworth: function(x){
				const container = document.querySelector("#item4741013");
				const innerBox = container.children[1].children[0].children[0];
				const last = innerBox.children[innerBox.children.length-1];

				last.removeAttribute("class");

				let li = document.createElement("li");
				let spanL = document.createElement("span");
				let spanName = document.createElement("span");
				let spanR = document.createElement("span");
				let i = document.createElement("i");

				li.classList.add("last");
				li.style.backgroundColor = "#65c90069";
				spanL.classList.add("divider");
				spanR.classList.add("desc");
				i.classList.add("networth-info-icon");
				i.setAttribute("title", "Torn Tools: Your networth is fetched from Torn's API which may have a small delay. It is fetched every time your reload this page.");
				spanName.style.backgroundColor = "rgba(0,0,0,0)";

				spanName.innerText = "Networth"
				spanR.innerText = "$" + String(numberWithCommas(x));
				spanR.style.paddingLeft = "12px";
				
				spanL.appendChild(spanName);
				spanR.appendChild(i);
				li.appendChild(spanL);
				li.appendChild(spanR);
				innerBox.appendChild(li);
			},
			capitalize: function(){
				String.prototype.capitalize = function () {
				  	return this.replace(/^./, function (match) {
				    	return match.toUpperCase();
				  	});
				};
			},
			days: function(x){
				return Math.floor(x/60/60/24); // seconds, minutes, hours
			},
			hours: function(x){
				return Math.floor(x/60/60); // seconds, minutes
			},
			cleanNr: function(x){
				return String(parseInt(x).toFixed())
			},
			numberWithCommas: function(x){
				return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
			}
		}

		tools.initialize();
		// Main(tools);
	})();
	// chrome.storage.local.get(["settings"], function(data){
	// 	if(data["ct"] === "show"){
	// 		settings = data["settings"];
	// 		let o = {}

	// 		var a = setInterval(function(){
	// 			const objects = document.querySelectorAll(".objects-layer .ct-object");
	// 			for(let object of objects){
	// 				let x = object.style.left;
	// 				let y = object.style.top;
	// 				let img = object.children[0].getAttribute("src");

	// 				let coordinates = `${x}, ${y}`;
	// 				if(!o[coordinates]){
	// 					o[coordinates] = img;
	// 				}
	// 			}
	// 			settings["ct-data"] = {...settings["ct-data"], ...o}
	// 			chrome.storage.local.set({"settings": settings}, function(){});
	// 		}, 2000)

	// 		setUpMap();
	// 	} else {
	// 		console.log("CT TURNED OFF");
	// 	}
	// });
}

// function setUpMap(){

// 	setUpWindow();


// 	// UPDATE MAP
// 	var b = setInterval(function(){
// 		chrome.storage.local.get(["settings"], function(data){
// 			settings = data["settings"];
// 			let ct_data = settings["ct-data"];

// 			let userPos = document.querySelector(".position___370Oi").innerText;
// 			let ttPos = document.querySelector("#ttMap #ttHeader #ttPos");
// 			ttPos.innerText = userPos;


// 		});
// 	}, 500);
// }

// function setUpWindow(){
// 	// WINDOW SET UP
// 	let mainFrame = document.querySelector(".content-wrapper");
// 	let div = document.createElement("div");
// 	let header = document.createElement("header");
// 	let pos = document.createElement("span");
// 	let resetPos = document.querySelector(".resetButton___1g2YH");
// 	let title = document.createElement("span");
// 	let gesture = document.querySelector("#makeGesture")

// 	div.id = "ttMap";
// 	div.style.height = "700px";
// 	div.style.marginTop = "10px"
// 	div.style.border = "1px solid black";

// 	header.style.backgroundColor = "#EAF3F7";
// 	header.id = "ttHeader";
// 	header.classList.add("title-wrap");
// 	header.style.fontFamily = "Fjalla one";
// 	header.style.paddingRight = "15px";

// 	title.innerText = "Christmas Town";
// 	title.style.marginLeft = "10px";
// 	title.style.fontSize = "16px";
// 	title.style.color = "rgb(102, 143, 177)";
// 	title.style.fontFamily = "inherit";

// 	pos.id = "ttPos";
// 	pos.style.fontSize = "13px";
// 	pos.style.color = "rgb(102, 143, 177)";
// 	pos.classList.add("position___370Oi");
// 	pos.style.fontFamily = "inherit";

// 	// resetPos.classList.add("resetButton___1g2YH");

// 	header.appendChild(title);
// 	header.appendChild(gesture);
// 	header.appendChild(resetPos);
// 	header.appendChild(pos);
// 	div.appendChild(header);
// 	mainFrame.appendChild(div);

// }