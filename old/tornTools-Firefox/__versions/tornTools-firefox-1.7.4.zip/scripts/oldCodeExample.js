///////////////
// OLD CODE
///////////////

// if(ps["virusescoded"] === undefined){
// 	addRow(`Viruses coded: 0/100`)
// } else if(ps["virusescoded"] >= 100){
// 	if(completed === "show"){
// 		addRow(`Viruses coded: Completed!`)
// 	}
// } else {
// 	addRow(`Viruses coded: ${ps["virusescoded"]}/100`)
// } 

// if(ps["bloodwithdrawn"] === undefined){
// 	addRow(`Blood bags filled: 0/250`)
// } else if(ps["bloodwithdrawn"] >= 1000){
// 	if(completed === "show"){
// 		addRow(`Blood bags filled: Completed!`)
// 	}
// } else if(ps["bloodwithdrawn"] >= 250){
// 	addRow(`Blood bags filled: ${ps["bloodwithdrawn"]}/1000`)
// } else {
// 	addRow(`Blood bags filled: ${ps["bloodwithdrawn"]}/250`)
// }

// if(ps["cityfinds"] === undefined){
// 	addRow(`City finds: 0/50`)
// } else if(ps["cityfinds"] >= 50){
// 	if(completed === "show"){
// 		addRow(`City finds: Completed!`)
// 	}
// } else {
// 	addRow(`City finds: ${ps["cityfinds"]}/50`)
// }

// if(ps["dumpfinds"] === undefined){
// 	addRow(`Dump finds: 0/1000`)
// } else if(ps["cityfinds"] >= 1000){
// 	if(completed === "show"){
// 		addRow(`Dump finds: Completed!`)
// 	}
// } else {
// 	addRow(`Dump finds: ${ps["dumpfinds"]}/1000`)
// }

// if(ps["itemsdumped"] === undefined){
// 	addRow(`Items dumped: 0/5000`)
// } else if(ps["itemsdumped"] >= 5000){
// 	if(completed === "show"){
// 		addRow(`Items dumped: Completed!`)
// 	}
// } else {
// 	addRow(`Items dumped: ${ps["itemsdumped"]}/5000`)
// }

// if(ps["alcoholused"] === undefined){
// 	addRow(`Alcohol used: 0/500`)
// } else if(ps["alcoholused"] >= 500){
// 	if(completed === "show"){
// 		addRow(`Alcohol used: Completed!`)
// 	}
// } else {
// 	addRow(`Alcohol used: ${ps["alcoholused"]}/500`)
// }

// if(ps["candyused"] === undefined){
// 	addRow(`Candy used: 0/500`)
// } else if(ps["candyused"] >= 500){
// 	if(completed === "show"){
// 		addRow(`Candy used: Completed!`)
// 	}
// } else {
// 	addRow(`Candy used: ${ps["candyused"]}/500`)
// }

// if(ps["medicalitemsused"] === undefined){
// 	addRow(`Meds used: 0/5000`)
// } else if(ps["medicalitemsused"] >= 5000){
// 	if(completed === "show"){
// 		addRow(`Meds used: Completed!`)
// 	}
// } else {
// 	addRow(`Meds used: ${ps["medicalitemsused"]}/5000`)
// }