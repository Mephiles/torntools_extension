const chrome = browser;
window.onload = () => {
	console.log("EXTENSION bazaar");
	(async () => {
		var tools = {};

		const mainModel = {
			initialize: function(){
				chrome.storage.local.get(["update"], function(data){
					const update = data["update"];
				
					const headers = document.querySelectorAll(".header___30pTh.desktop___vemcY");
					const version = chrome.runtime.getManifest().version;
					
					var container;
					for(let header of headers){
						if(header.innerText === "Areas"){
							container = header.parentElement.children[1];
						}
					}
					const nextElement = document.querySelector("#nav-home");

					let div = document.createElement("div");
					let innerDiv = document.createElement("div");
					let link = document.createElement("a");
					let span = document.createElement("span");
					let icon = document.createElement("div");

					div.classList.add("area-desktop___29MUo");
					innerDiv.classList.add("area-row___51NLj");
					if(update){
						innerDiv.style.backgroundColor = "#8eda53b0";
					}

					link.addEventListener("click", function(){
						chrome.runtime.sendMessage({"action": "openOptionsPage"});
					});

					span.innerHTML = `Torn<span style="font-weight:600;margin:0;line-height:7px;">Tools</span>  v${version}`;
					span.setAttribute("style", `
						height: 20px;
						line-height: 20px;
					`);

					const src = chrome.extension.getURL("images/icon50.png");
					icon.setAttribute("style", `
						width: 15px;
						height: 15px;
						background-size: cover;
						background-image: url(${src});
						margin-top: 2px;
						margin-left: 10px;
						margin-right: 6px;
						float: left;
					`)

					link.appendChild(icon)
					link.appendChild(span);
					innerDiv.appendChild(link);
					div.appendChild(innerDiv);
					container.insertBefore(div, nextElement);

					// functions
					tools.capitalize();
				});
			},
			get_api: async function(http, api_key){
				const response = await fetch(http + "&key=" + api_key)
				const result = await response.json()
				return result;
			},
			compare: function(a,b){
				if (a.cost < b.cost)
				  return -1;
				if (a.cost > b.cost)
				  return 1;
				return 0;
			},
			getLowest: function(lists){
				var lowest;

				for(let list in lists){
					for(let id in lists[list]){
						let price = parseInt(lists[list][id]["cost"]);

						if(!lowest){
							lowest = price;
						} else if(price < lowest){
							lowest = price
						}
					}
				}
				return lowest;
			},
			countPerks: function(perks){
				let total = 0;

				for(let perklist of perks){
					for(let perk of perklist){
						total++;
					}
				}

				return total
			},
			displayNetworth: function(x){
				const container = document.querySelector("#item4741013");
				const innerBox = container.children[1].children[0].children[0];
				const last = innerBox.children[innerBox.children.length-1];

				last.removeAttribute("class");

				let li = document.createElement("li");
				let spanL = document.createElement("span");
				let spanName = document.createElement("span");
				let spanR = document.createElement("span");
				let i = document.createElement("i");

				li.classList.add("last");
				li.style.backgroundColor = "#65c90069";
				spanL.classList.add("divider");
				spanR.classList.add("desc");
				i.classList.add("networth-info-icon");
				i.setAttribute("title", "Torn Tools: Your networth is fetched from Torn's API which may have a small delay. It is fetched every time your reload this page.");
				spanName.style.backgroundColor = "rgba(0,0,0,0)";

				spanName.innerText = "Networth"
				spanR.innerText = "$" + String(numberWithCommas(x));
				spanR.style.paddingLeft = "12px";
				
				spanL.appendChild(spanName);
				spanR.appendChild(i);
				li.appendChild(spanL);
				li.appendChild(spanR);
				innerBox.appendChild(li);
			},
			capitalize: function(){
				String.prototype.capitalize = function () {
				  	return this.replace(/^./, function (match) {
				    	return match.toUpperCase();
				  	});
				};
			},
			days: function(x){
				return Math.floor(x/60/60/24); // seconds, minutes, hours
			},
			hours: function(x){
				return Math.floor(x/60/60); // seconds, minutes
			},
			cleanNr: function(x){
				return String(parseInt(x).toFixed())
			},
			numberWithCommas: function(x){
				return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
			}
		}

		const bazaarModel = {
			displayBazaarItemPrice: function(price, row){
				// let priceContainer = row.children[2].children[0].children[2].children[0].children[0];
				// priceContainer.value = String(numberWithCommas(price));
				// priceContainer.parentElement.classList.add("success");

				let priceContainer = row.children[2].children[0].children[2].children[0].children[0];
				priceContainer.setAttribute("placeholder", String(this.numberWithCommas(price)));

				// SET PLACEHOLDERS TO CERTAIN COLOR
				let css = `li[data-reactid="${row.getAttribute("data-reactid")}"] input.clear-all.input-money::placeholder {color: #3ec505}`;
				let style = document.createElement("style");

				if(style.styleSheet){
					style.styleSheet.cssText = css;
				} else {
					style.appendChild(document.createTextNode(css));
				}

				document.getElementsByTagName("head")[0].appendChild(style);
			},
			getBazaarItemPrice: async function(id, api_key, prices){
				let value;

				if(!prices[id]){
					value = await this.get_api(`https://api.torn.com/market/${id}?selections=bazaar,itemmarket`, api_key).then(data => {
						value = this.getLowest([data["bazaar"], data["itemmarket"]]);
						return value
					});
				} else {
					value = prices[id];
				}
				return value
			},
			modifyItem: async function(el, itemlist, api_key, itemPrices){
				let row;
				let itemName;
				try{
					row = el.parentElement.parentElement.parentElement.parentElement;
					itemName = row.children[1].children[1].innerText.split(" x")[0];
				} catch(err){
					row = el.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement;
					itemName = row.children[1].children[1].innerText.split(" x")[0];
				}
				let id;

				for(let i in itemlist){
					if(itemlist[i]["name"] === itemName){
						id = i;
					}
				}

				await this.getBazaarItemPrice(id, api_key, itemPrices).then(data => {
					let price = data;
					itemPrices[id] = price
					this.displayBazaarItemPrice(price, row);
				});
			},
			addView: function(){
				let check = document.querySelector("input[value='ADD TO BAZAAR']");
				if(check){
					return true;
				}
				return false;
			},
			openAllItems: function(){
				// APPEND ALL ITEMS
				var checkboxes = document.querySelectorAll("a[role='presentation']");
				for(let box of checkboxes){
					if(box.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.getAttribute("data-group") === "parent"){
						box.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.children[1].click();
					}
				}
				return checkboxes.length;
			},
			setAppStatus: function(status){
				const icons = {
					"disabled": "disabled.png",
					"notready": "notready.png",
					"ready": "ready.png"
				}
				const src = chrome.extension.getURL("images/"+icons[status]);
				if(!document.querySelector("#ttBazaarStatus")){
					const container = document.querySelector(".items-footer.clearfix");
					
					let div = document.createElement("div");
					div.setAttribute("style", `
						width: 20px;
						height: 20px;
						background-image: url("${src}");
						float: right;
						background-size: cover;
					`);
					div.id = "ttBazaarStatus";

					container.appendChild(div);
				} else {
					console.log("HERE", src)
					document.querySelector("#ttBazaarStatus").style.backgroundImage = `url(${src})`
				}
			}
		}

		tools = {...tools, ...mainModel, ...bazaarModel}

		// const sources = {
		// 	mainModel: 'scripts/models/mainModel.js',
		// 	bazaarModel: 'scripts/models/bazaarModel.js'
		// }

		// for(let src in sources){
		// 	let funcs = await import(chrome.extension.getURL(sources[src]));
		// 	tools = {...tools, ...funcs}
		// }
		tools.initialize();
		Main(tools);
	})();
}

function Main(tools){
	chrome.storage.local.get(["itemlist", "settings", "api_key"], function(data){
		const settings = data["settings"];
		const showBazaar = settings["other"]["bazaar"];
		const itemlist = data["itemlist"]["items"];
		const api_key = data["api_key"];
		var itemPrices = {}
		var addV = false;

		// CHECK FOR SITE CHANGE
		let checker = setInterval(function(){
			if(showBazaar){
				if(tools.addView()){
					if(addV === false){
						tools.setAppStatus("notready");
						addV = true;
						subMain(itemlist, api_key, itemPrices, tools);
					}
				} else {
					addV = false;
					console.log("NOT IN ADD VIEW")
				}
			} else {
				console.log("BAZAAR HELPER TURNED OFF")
			}
		}, 1000);
	});
}

function subMain(itemlist, api_key, itemPrices, tools){
	var initialCount;

	setTimeout(function(){}, 500) // WAIT FOR INPUTS
	const inputs = document.querySelectorAll("input[placeholder='Qty']");
	if(inputs.length > 0){
		for(let input of inputs){
			input.addEventListener("focus", function(){
				tools.modifyItem(this, itemlist, api_key, itemPrices);	
			});
		}
		tools.setAppStatus("ready");
	}
	initialCount = tools.openAllItems();
	var checkCounter = 0;

	let b = setInterval(function(){
		var checkboxes = document.querySelectorAll("a[role='presentation']");
		if(checkboxes.length > initialCount || checkCounter > 5){
			for(let box of checkboxes){
				box.addEventListener("click", function(){
					tools.modifyItem(this, itemlist, api_key, itemPrices)
				})
			}
			console.log("WAITING FOR INPUTS")
			clearInterval(b);
		}
		checkCounter += 1;
	}, 500)
}