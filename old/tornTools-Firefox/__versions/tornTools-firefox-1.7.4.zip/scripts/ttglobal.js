if(!chrome){chrome = browser}

window.onload = () => {
	(async () => {
		var tools = {};

		const mainModel = {
			initialize: function(){
				chrome.storage.local.get(["update"], function(data){
					const update = data["update"];
				
					const headers = document.querySelectorAll(".header___30pTh.desktop___vemcY");
					const version = chrome.runtime.getManifest().version;
					
					var container;
					for(let header of headers){
						if(header.innerText === "Areas"){
							container = header.parentElement.children[1];
						}
					}
					const nextElement = document.querySelector("#nav-home");

					let div = document.createElement("div");
					let innerDiv = document.createElement("div");
					let link = document.createElement("a");
					let span = document.createElement("span");
					let icon = document.createElement("div");

					div.classList.add("area-desktop___29MUo");
					innerDiv.classList.add("area-row___51NLj");
					if(update){
						innerDiv.style.backgroundColor = "#8eda53b0";
					}

					link.addEventListener("click", function(){
						chrome.runtime.sendMessage({"action": "openOptionsPage"});
					});

					span.innerHTML = `Torn<span style="font-weight:600;margin:0;line-height:7px;">Tools</span>  v${version}`;
					span.setAttribute("style", `
						height: 20px;
						line-height: 20px;
					`);

					const src = chrome.extension.getURL("images/icon50.png");
					icon.setAttribute("style", `
						width: 15px;
						height: 15px;
						background-size: cover;
						background-image: url(${src});
						margin-top: 2px;
						margin-left: 10px;
						margin-right: 6px;
						float: left;
					`)

					link.appendChild(icon)
					link.appendChild(span);
					innerDiv.appendChild(link);
					div.appendChild(innerDiv);
					container.insertBefore(div, nextElement);

					// functions
					tools.capitalize();
				});
			},
			get_api: async function(http, api_key){
				const response = await fetch(http + "&key=" + api_key)
				const result = await response.json()
				return result;
			},
			compare: function(a,b){
				if (a.cost < b.cost)
				  return -1;
				if (a.cost > b.cost)
				  return 1;
				return 0;
			},
			getLowest: function(lists){
				var lowest;

				for(let list in lists){
					for(let id in lists[list]){
						let price = parseInt(lists[list][id]["cost"]);

						if(!lowest){
							lowest = price;
						} else if(price < lowest){
							lowest = price
						}
					}
				}
				return lowest;
			},
			countPerks: function(perks){
				let total = 0;

				for(let perklist of perks){
					for(let perk of perklist){
						total++;
					}
				}

				return total
			},
			displayNetworth: function(x){
				const container = document.querySelector("#item4741013");
				const innerBox = container.children[1].children[0].children[0];
				const last = innerBox.children[innerBox.children.length-1];

				last.removeAttribute("class");

				let li = document.createElement("li");
				let spanL = document.createElement("span");
				let spanName = document.createElement("span");
				let spanR = document.createElement("span");
				let i = document.createElement("i");

				li.classList.add("last");
				li.style.backgroundColor = "#65c90069";
				spanL.classList.add("divider");
				spanR.classList.add("desc");
				i.classList.add("networth-info-icon");
				i.setAttribute("title", "Torn Tools: Your networth is fetched from Torn's API which may have a small delay. It is fetched every time your reload this page.");
				spanName.style.backgroundColor = "rgba(0,0,0,0)";

				spanName.innerText = "Networth"
				spanR.innerText = "$" + String(numberWithCommas(x));
				spanR.style.paddingLeft = "12px";
				
				spanL.appendChild(spanName);
				spanR.appendChild(i);
				li.appendChild(spanL);
				li.appendChild(spanR);
				innerBox.appendChild(li);
			},
			capitalize: function(){
				String.prototype.capitalize = function () {
				  	return this.replace(/^./, function (match) {
				    	return match.toUpperCase();
				  	});
				};
			},
			days: function(x){
				return Math.floor(x/60/60/24); // seconds, minutes, hours
			},
			hours: function(x){
				return Math.floor(x/60/60); // seconds, minutes
			},
			cleanNr: function(x){
				return String(parseInt(x).toFixed())
			},
			numberWithCommas: function(x){
				return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
			}
		}

		tools = {...tools, ...mainModel}

		// const sources = {
		// 	mainModel: 'scripts/models/mainModel.js',
		// }

		// for(let src in sources){
		// 	let funcs = await import(chrome.extension.getURL(sources[src]));
		// 	tools = {...tools, ...funcs}
		// }
		tools.initialize();
		// Main(tools);
	})();
}