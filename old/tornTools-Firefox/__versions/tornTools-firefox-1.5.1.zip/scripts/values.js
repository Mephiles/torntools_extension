const chrome = browser;
var apiCounter = 0;
var apiLimit = 60;

window.onload = () => {
	console.log("START values script")

	chrome.storage.local.get(["itemlist", "settings", "api_key"], function(data){
		const tradecalc = data["settings"]["other"]["tradecalc"];
		const itemlist = data["itemlist"]["items"];
		const api_key = data["api_key"];
		var tradeV = false;

		// CHECK FOR SITE CHANGE
		let checker = setInterval(function(){
			if(tradecalc){
				if(tradeView()){
					if(tradeV === false){
						tradeV = true;
						console.log("CALCULATING")
						Main(itemlist, api_key);
					}
				} else {
					tradeV = false;
					console.log("NOT IN TRADE VIEW")
				}
			} else {
				console.log("TRADE CALCULATOR TURNED OFF")
			}
		}, 1000);

		async function Main(itemlist, api_key){
			const tradeContainer = document.querySelector(".trade-cont");
			const leftSide = document.querySelector(".trade-cont .user.left");
			const rightSide = document.querySelector(".trade-cont .user.right");
			const adds = document.querySelectorAll(".log li div")
			
			// API COUNTER RESET
			var a = setInterval(function(){
			    console.log("API COUNTER: ", apiCounter)
			    apiCounter = 0;
			    console.log("API COUNTER CLEARED: ", apiCounter)
			}, 60*1000); //60 * 1 sec

			const leftItems = getLeftItemIDs(itemlist);
			const rightItems = getRightItemIDs(itemlist);
			var prices = {}

			if(leftItems){
				await calculateItemsValue(leftItems, api_key).then(data => {
					prices = {...prices, ...data["prices"]}
					displayValue(leftSide, data["value"]);
				})
			}

			if(rightItems){
				await calculateItemsValue(rightItems, api_key, prices).then(data => {
					prices = {...prices, ...data["prices"]}
					displayValue(rightSide, data["value"]);
				})
			}

			// SHOW VALUES FOR INDEPENDENT ADDS
			for(let add of adds){
				let text = add.innerText
				if(text.indexOf("added") > -1){
					
					// remove unwanted parts
					text = text.replace(/ added/g, "")
					text = text.replace(/ to the trade./g, "")
					text = text.replace(text.split(" ")[0] + " ", "")
					var items = text.split(", ");

					var resultItems = {}

					for(let item of items){
						let name = item.split(" x")[0];
						let q = item.split(" x")[1];
						let id;

						for(let i in itemlist){
							if(itemlist[i]["name"] === name){
								resultItems[i] = q;
							}
						}
					}

					if(Object.keys(resultItems).length){
						await calculateItemsValue(resultItems, api_key, prices).then(data => {
							displayLogValue(add, data["value"]);
						});
					}
				}
			}
		}
	});
}

function displayLogValue(add, x){
	let span = document.createElement("span");
	
	span.style.float = "right";
	span.style.color = "#678c00";
	span.innerText = "$"+String(numberWithCommas(x))

	add.appendChild(span);
}

function getLeftItemIDs(itemlist){
	var result = {};

	let items = document.querySelectorAll(".user.left .cont .color2 .desc li .name.left");

	if(items[0].innerText !== "No items in trade"){
		for(let item of items){
			let parts = item.innerText.split(" x");
			let name = parts[0];
			let q = parts[1];

			for(let id in itemlist){
				if(itemlist[id]["name"] === name){
					result[id] = q;
				}
			}
		}
		return result;
	}
	return "none";
}

function getRightItemIDs(itemlist){
	var result = {};

	let items = document.querySelectorAll(".user.right .cont .color2 .desc li .name.left");
	if(items.length === 0){
		return "none"
	}

	for(let item of items){
		let parts = item.innerText.split(" x");
		let name = parts[0];
		let q = parts[1];

		for(let id in itemlist){
			if(itemlist[id]["name"] === name){
				result[id] = q;
			}
		}
	}
	return result;
}

async function calculateItemsValue(items, api_key, pricelist){
	if(items === "none"){
		return {value: 0, prices: {}}
	}

	var value = 0;
	var prices = {}
	
	for(let id in items){
		if(pricelist && pricelist[id]){
			let lowest = parseInt(pricelist[id]);
			let q = items[id];

			value += lowest*q;
		} else {
			value += await get_api(`https://api.torn.com/market/${id}?selections=bazaar,itemmarket`, api_key)
			.then(data => {
				var lowest = getLowest([data["bazaar"], data["itemmarket"]]);
				let q = items[id];
				prices[id] = lowest;
				return lowest * q;
			})
			
		}
	}	
	return {value: value, prices: prices};
}

function displayValue(side, x){
	let div = document.createElement("div");
	let span = document.createElement("span");

	div.style.height = "30px";
	div.style.lineHeight = "30px";
	div.style.border = "0.5px solid black";
	div.style.fontWeight = "600";
	div.style.paddingLeft = "15px";
	div.innerText = "Items value: "

	span.style.color = "#678c00",
	span.style.fontWeight = "400";
	span.innerText = "$"+String(numberWithCommas(x))

	div.appendChild(span);
	side.appendChild(div);
}

function getLowest(lists){
	var lowest;

	for(let list in lists){
		for(let id in lists[list]){
			let price = parseInt(lists[list][id]["cost"]);

			if(!lowest){
				lowest = price;
			} else if(price < lowest){
				lowest = price
			}
		}
	}
	return lowest;
}

function tradeView(){
	const tradeContainer = document.querySelector(".trade-cont");
	if(!tradeContainer){
		return false;
	}
	return true
}

async function get_api(http, api_key) {
    if(apiCounter >= apiLimit){
        setTimeout(function(){}, 30*1000) // 30 * 1 sec
    }
    apiCounter++;
    console.log("API COUNTER: ", apiCounter)
  	const response = await fetch(http + "&key=" + api_key)
  	return await response.json();
}

const numberWithCommas = (x) => {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function compare(a,b) {
  if (a.cost < b.cost)
    return -1;
  if (a.cost > b.cost)
    return 1;
  return 0;
}