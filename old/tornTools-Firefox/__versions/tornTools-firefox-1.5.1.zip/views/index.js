const chrome = browser;

window.onload = () => {
	console.log("START INDEX");

	chrome.storage.local.get(["api_key"], function(data){
		if(!data["api_key"]){
			const apiField = document.querySelector("#api-field");
			const setButton = document.querySelector("#set-button");

			setButton.addEventListener("click", function(){
				let apiKey = apiField.value

				chrome.storage.local.set({"api_key": apiKey}, function(){
					console.log("API KEY set.");

					let port = chrome.runtime.connect({
					    name: "PROGRAM START ORDER"
					});

					port.postMessage("START");

					setTimeout(function(){
						setWindow();
					},1000);
				});
			});
		} else {
			setWindow();
		}
	});
}

function setWindow(){
	chrome.storage.local.get(["settings"], function(data){
		window.location.href = data["settings"]["default_window"] + ".html";
	});
}