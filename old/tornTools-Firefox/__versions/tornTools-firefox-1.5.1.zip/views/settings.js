const chrome = browser;

const changeLog = {
	"v1.5.1": [
		"Temporarily disabled Bazaar Helper as there is a bug with pricing. Patch coming soon!"
	],
	"v1.5": [
		"Added bazaar price helper - auto complete prices (lowest on market)",
		"Added auction helper - show your own auctions all together",
		"Technical: reworked settings section of the extension"
	],
	"v1.4": [
		"Fixed bug where trade values where not displayed in case of 0 items",
		"Added changelog",
		"Removed help section from settings",
		"Reduced api request amount in trade view. Set api limit to 60 requests on trade view."
	]
}

window.onload = () => {
	console.log("START SETTINGS")
	setUpWindow();	
}

function setUpWindow(){
	chrome.storage.local.get(["settings"], function(data){
		const settings = data["settings"]

		setSettings(settings);

		const api_field = document.querySelector("#api-input");
		const api_button = document.querySelector("#change-api");
		const setting_boxes = document.querySelectorAll(".setting");
		const changelog_ul = document.querySelector("#changelog");
		const currentVersion = document.querySelector("#current-version");
		//const networth_refresh = document.querySelector("#networth-refresh");

		// EVENT LISTENERS
		for(let setting of setting_boxes){
			setting.addEventListener("click", function(){
				applySettings();
			})
		}

		api_button.addEventListener("click", function(){
			let api_key = api_field.value;

			chrome.storage.local.set({"api_key": api_key}, function(){
				console.log("API KEY SET");
				getTornItemList(api_key);
			});
		});

		// networth_refresh.addEventListener("click", function(){
		// 	chrome.storage.local.get(["api_key"], function(data){
		// 		const api_key = data["api_key"];
		// 		setNetworth(api_key);
		// 	});
		// });

		let ver = chrome.runtime.getManifest().version
		currentVersion.innerText = "Current version: " + ver;

		// ADD CHANGELOG
		for(let v in changeLog){
			let mainSection = document.createElement("li");
			let lowerSection = document.createElement("ul");
			mainSection.innerText = v;
			if(v.indexOf(ver) != -1){
				mainSection.style.backgroundColor = "#ffff0240";
			}

			for(let bug of changeLog[v]){
				let li = document.createElement("li");
				li.innerText = bug;
				lowerSection.appendChild(li);	
			}

			mainSection.appendChild(lowerSection);
			changelog_ul.appendChild(mainSection);
		}
	});
}

function setSettings(settings){
	var tab_checks = document.querySelectorAll("#tabs input");
	var ach_compl = document.querySelector("#achievements-completed");
	var radios = document.querySelectorAll("#def_windows input");
	var trade_calculator = document.querySelector("#calculator-trade");
	var achievements_toggle = document.querySelector("#achievements-toggle");
	var bazaar_helper = document.querySelector("#bazaar-helper");
	var auction_helper = document.querySelector("#auction-helper");
	
	// tabs
	for(let check of tab_checks){
		for(let tab of settings["tabs"]){
			if(check.nextElementSibling.innerText.indexOf(tab) > -1){
				check.checked = true;
			}
		}
	}

	// achievements
	if(settings["other"]["achievements"]){
		achievements_toggle.checked = true;
	}

	// completed achievements
	if(settings["other"]["completed"]){
		ach_compl.checked = true;
	}

	// default window
	for(let radio of radios){
		if(radio.nextElementSibling.innerText.toLowerCase() === settings["default_window"]){
			radio.checked = true;
		}
	}

	// trade calculator
	if(settings["other"]["tradecalc"]){
		trade_calculator.checked = true;
	}

	// bazaar helper
	if(settings["other"]["bazaar"]){
		bazaar_helper.checked = true;
	}

	// auction helper
	if(settings["other"]["auction"]){
		auction_helper.checked = true;
	}

	// var networth_check = document.querySelector("#otherchecks #networth-check");
	// if(settings["other"]["networth"]){
	// 	networth_check.checked = true;
	// }
}

function applySettings(){
	var settings = {
		"tabs": [],
		"default_window": "market",
		"other": {
			"achievements": false,
			"completed": false,
			"networth": false,
			"ct": false,
			"bazaar": false,
			"auction": false
		}
	}
	var checks = document.querySelectorAll("#tabs input");
	var radios = document.querySelectorAll("#def_windows input");
	var ach_compl = document.querySelector("#achievements-completed");
	var trade_calculator = document.querySelector("#calculator-trade");
	var achievements_toggle = document.querySelector("#achievements-toggle");
	var bazaar_helper = document.querySelector("#bazaar-helper");
	var auction_helper = document.querySelector("#auction-helper");
	
	for(let check of checks){
		if(check.checked){
			settings["tabs"].push(check.value);
		}
	}

	for(let radio of radios){
		if(radio.checked){
			settings["default_window"] = radio.nextElementSibling.innerText.toLowerCase();
		}
	}

	if(ach_compl.checked){
		settings["other"]["completed"] = true;
	}

	if(trade_calculator.checked){
		settings["other"]["tradecalc"] = true;
	}

	if(achievements_toggle.checked){
		settings["other"]["achievements"] = true;
	}

	if(bazaar_helper.checked){
		settings["other"]["bazaar"] = false; // CHANGE BACK WHEN WORKS
	}

	if(auction_helper.checked){
		settings["other"]["auction"] = true;
	}

	// var networth_check = document.querySelector("#otherchecks #networth-check");
	// if(networth_check.checked){
	// 	networth = true;
	// } else {
	// 	networth = false;
	// }

	console.log("SETTINGS", settings)

	chrome.storage.local.set({"settings": settings}, function(){
		console.log("SETTINGS SET")
	})
}

function getTornItemList(api_key){
	get_api("https://api.torn.com/torn/?selections=items", api_key).then((data) => {
		chrome.storage.local.set({"itemlist": data}, function(){
			console.log("Itemlist set.");
			$("#message").text("Api key changed.");
			$("#message").slideDown("slow", function(){});
			setTimeout(function(){
				$("#message").slideUp("slow", function(){});
			}, 1500);
		});
	})
}

async function setNetworth(api_key){
	const inventory = await get_api(links.inventory, api_key).then(data => {
		return data["inventory"];
	});

	var totalValue = 0;
	var items = {};
	var itemString = "";

	for(let item of inventory){
		itemsettings[item["ID"]] = item["quantity"];
		itemString += String(item["ID"]) + ",";
	}

	itemString = itemString.slice(0, itemString.length-1);

	const prices = await get_api(`https://api.torn.com/market/${itemString}?selections=bazaar,itemmarket`, api_key);

	for(let item in prices){
		let lowest = getLowest([item["bazaar"], item["itemmarket"]]);
		totalValue += lowest * parseInt(itemsettings[item]);
	}

	chrome.storage.local.set({"networthValue": totalValue}, function(){
		console.log("Networth set.")
	});
}

function getLowest(lists){
	var lowest;

	for(let list of lists){
		for(let id in list){
			let price = parseInt(data[list][id]["cost"]);

			if(!lowest){
				lowest = price;
			} else if(price < lowest){
				lowest = price
			}
		}
	}
	return lowest;
}

async function get_api(http, api_key) {
  	const response = await fetch(http + "&key=" + api_key)
  	return await response.json()
}