const chrome = browser;
var apiCounter = 0;
var apiLimit = 60;

window.onload = () => {
	console.log("EXTENSION bazaar");

	chrome.storage.local.get(["itemlist", "settings", "api_key"], function(data){
		const settings = data["settings"];
		const showBazaar = settings["other"]["bazaar"];
		const itemlist = data["itemlist"]["items"];
		const api_key = data["api_key"];
		var itemPrices = {}
		var addV = false;

		// CHECK FOR SITE CHANGE
		let checker = setInterval(function(){
			if(showBazaar){
				if(addView()){
					if(addV === false){
						addV = true;
						console.log("WAITING FOR INPUTS")
						Main(itemlist, api_key, itemPrices);
					}
				} else {
					addV = false;
					console.log("NOT IN ADD VIEW")
				}
			} else {
				console.log("BAZAAR HELPER TURNED OFF")
			}
		}, 1000)

		// API COUNTER RESET
		var a = setInterval(function(){
		    console.log("API COUNTER: ", apiCounter)
		    apiCounter = 0;
		    console.log("API COUNTER CLEARED: ", apiCounter)
		}, 60*1000); //60 * 1 sec
	});
}

function Main(itemlist, api_key, itemPrices){
	var initialCount;

	setTimeout(function(){}, 500) // WAIT FOR INPUTS
	const inputs = document.querySelectorAll("input[placeholder='Qty']");
	if(inputs.length > 0){
		for(let input of inputs){
			input.addEventListener("focus", function(){
				modifyItem(this, itemlist, api_key, itemPrices);	
			});
		}
	}
	initialCount = openAll()

	let b = setInterval(function(){
		var checkboxes = document.querySelectorAll("a[role='presentation']");
		if(checkboxes.length > initialCount){
			for(let box of checkboxes){
				box.addEventListener("click", function(){
					modifyItem(this, itemlist, api_key, itemPrices)
				})
			}
			clearInterval(b);
		}
	}, 500)
}

function openAll(){
	// APPEND ALL ITEMS
	var checkboxes = document.querySelectorAll("a[role='presentation']");
	for(let box of checkboxes){
		if(box.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.getAttribute("data-group") === "parent"){
			box.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.children[1].click();
		}
	}
	return checkboxes.length;
}

async function modifyItem(el, itemlist, api_key, itemPrices){
	let row;
	let itemName;
	try{
		row = el.parentElement.parentElement.parentElement.parentElement;
		itemName = row.children[1].children[1].innerText.split(" x")[0];
	} catch(err){
		row = el.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement;
		itemName = row.children[1].children[1].innerText.split(" x")[0];
	}
	let id;

	for(let i in itemlist){
		if(itemlist[i]["name"] === itemName){
			id = i;
		}
	}

	await getPrice(id, api_key, itemPrices).then(data => {
		let price = data;
		itemPrices[id] = price
		displayPrice(price, row);
	});
}

function addView(){
	let check = document.querySelector("input[value='ADD TO BAZAAR']");
	if(check){
		return true;
	}
	return false;
}

async function getPrice(id, api_key, prices){
	let value;

	if(!prices[id]){
		value = await get_api(`https://api.torn.com/market/${id}?selections=bazaar,itemmarket`, api_key).then(data => {
			value = getLowest([data["bazaar"], data["itemmarket"]]);
			return value
		});
	} else {
		value = prices[id];
	}
	return value
}

function displayPrice(price, row){
	// let priceContainer = row.children[2].children[0].children[2].children[0].children[0];
	// priceContainer.value = String(numberWithCommas(price));
	// priceContainer.parentElement.classList.add("success");

	let priceContainer = row.children[2].children[0].children[2].children[0].children[0];
	priceContainer.setAttribute("placeholder", String(numberWithCommas(price)));

	// SET PLACEHOLDERS TO CERTAIN COLOR
	let css = `li[data-reactid="${row.getAttribute("data-reactid")}"] input.clear-all.input-money::placeholder {color: #3ec505}`;
	let style = document.createElement("style");

	if(style.styleSheet){
		style.styleSheet.cssText = css;
	} else {
		style.appendChild(document.createTextNode(css));
	}

	document.getElementsByTagName("head")[0].appendChild(style);
}

function getLowest(lists){
	var lowest;

	for(let list in lists){
		for(let id in lists[list]){
			let price = parseInt(lists[list][id]["cost"]);

			if(!lowest){
				lowest = price;
			} else if(price < lowest){
				lowest = price
			}
		}
	}
	return lowest;
}

async function get_api(http, api_key) {
    if(apiCounter >= apiLimit){
        setTimeout(function(){}, 30*1000) // 30 * 1 sec
    }
    apiCounter++;
    console.log("API COUNTER: ", apiCounter)
  	const response = await fetch(http + "&key=" + api_key)
  	return await response.json();
}

const numberWithCommas = (x) => {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}